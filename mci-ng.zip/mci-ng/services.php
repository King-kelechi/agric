<?php include("assets/include/header.php"); ?>  
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(assets/images/backgrounds/page-header-bg-1-1.jpg);"></div>
            <!-- Sliding section Start -->
            <div class="text-slider  wow fadeInUp" data-wow-delay="500ms">
                <div class="text-slider__inner">
                    <div class="text-slider__item">
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                        <div class="text-slider__item__text"><span>*</span> Our Services</div>
                    </div>
                </div>
            </div>
            <!-- Sliding section End -->
            <div class="container">
                <h2 class="page-header__title">Our Services</h2>
                <div class="eolimn-breadcrumb">
                    <ul class="eolimn-breadcrumb__list list-unstyled">
                        <li class="eolimn-breadcrumb__list__item"><a href="index.php">Home</a></li>
                        <li class="eolimn-breadcrumb__list__item"><span>Our Services</span></li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="service-page">
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-1.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-thermo-stone.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-thermo-stone.php">technical service</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-2.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-solar-service.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-solar-service.php">solar service</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-3.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-energy-panels.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-energy-panels.php">energy panels</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='700ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-4.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-wind-generator.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-wind-generator.php">wind generator</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-5.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-solar-battery.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-solar-battery.php">Energy Storage plan</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-6.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-pv-systems.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-pv-systems.php">Off-Grid Solutions</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-7.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-pv-systems.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-pv-systems.php">Upgrades & Expansions</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='700ms'>
                            <div class="service-card__image">
                                <img src="assets/images/service/service-1-8.png" alt="image">
                            </div>
                            <div class="service-card__content">
                                <a href="service-d-hydropower-plants.php" class="service-card__btn"><i class="icon-double-arrow"></i></a>
                                <h3 class="service-card__title"><a href="service-d-hydropower-plants.php">Hydropower Plants</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="who-we who-we--service">
            <div class="who-we__bg" style="background-image: url(assets/images/shapes/service-shape-1-1.png);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="who-we__left">
                            <div class="who-we__thumb wow fadeInLeft" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <img src="assets/images/resources/whe-we-1-1.png" alt="image">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="who-we__right">
                            <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="sec-title__icon icon-solar-panel"></i>
                                    <h6 class="sec-title__tagline">WHO WE ARE</h6>
                                </div>
                                <h3 class="sec-title__title">Our Company Sees a Climate Solutions</h3>
                            </div>
                            <div class="tabs-box">
                                <div class="who-we__tab wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <div class="who-we__tab__link tab-link">
                                        <button data-tab="#research" class=" eolimn-btn tab-btn active-btn">our mission</button>
                                        <button data-tab="#marketing" class=" eolimn-btn tab-btn">our vision</button>
                                        <button data-tab="#planning" class=" eolimn-btn tab-btn">know more</button>
                                    </div>
                                </div>

                                <div class="tabs-content wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <div class="who-we__item fadeInUp animated tab active-tab" id="research">
                                        <p class="who-we__item__text">our mission is to lead the transition to a sustainable future by providing innovative climate solutions.</p>
                                        <div class="who-we__skills">
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Wind turbines</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="95%">
                                                        <div class="progress-box__number count-text">95%</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Hybrid energy</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="70%">
                                                        <div class="progress-box__number count-text">70%</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Solar energy</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="97%">
                                                        <div class="progress-box__number count-text">97%</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="who-we__item fadeInUp animated tab" id="marketing">
                                        <p class="who-we__item__text">We aspire to create a future where renewable energy powers every home and business, sustainable infrastructure supports vibrant communities, and innovative technologies mitigate climate change effectively.</p>
                                        <div class="who-we__skills">
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Wind turbines</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="95%">
                                                        <div class="progress-box__number count-text">95%</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Hybrid energy</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="70%">
                                                        <div class="progress-box__number count-text">70%</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Solar energy</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="97%">
                                                        <div class="progress-box__number count-text">97%</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="who-we__item fadeInUp animated tab" id="planning">
                                        <p class="who-we__item__text">Our financial services support climate-friendly investments, ensuring a holistic approach to a greener, more resilient world.</p>
                                        <div class="who-we__skills">
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Wind turbines</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="95%">
                                                        <div class="progress-box__number count-text">95%</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Hybrid energy</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="70%">
                                                        <div class="progress-box__number count-text">70%</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--skills-item -->
                                            <div class="who-we__progress progress-box">
                                                <h4 class="progress-box__title">Solar energy</h4>
                                                <div class="progress-box__bar">
                                                    <div class="progress-box__bar__inner count-bar" data-percent="97%">
                                                        <div class="progress-box__number count-text">97%</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="who-we__shape">
                <img src="assets/images/shapes/service-2-1.png" alt>
            </div>
        </section>

        <section class="service-contact">
            <div class="container">
                <div class="service-contact__inner wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                    <div class="service-contact__bg" style="background-image: url(assets/images/shapes/contact-bg-1-1.png);"></div>
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="service-contact__left">
                                <div class="service-contact__top">
                                    <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                        <div class="d-flex align-items-center justify-content-start">
                                            <i class="sec-title__icon icon-solar-panel"></i>
                                            <h6 class="sec-title__tagline">contact wit us</h6>
                                        </div>
                                        <h3 class="sec-title__title">get in touch</h3>
                                    </div>
                                    <p class="service-contact__text">Everyday the sun provides us with an abundance of free energy by placing solar panels on your roof.</p>
                                </div>
                                <ul class="service-contact__list list-unstyled">
                                    <li class="service-contact__list__item"><i class="icon-check"></i>Whether building on land or over water</li>
                                </ul>
                                <div class="service-contact__author">
                                    <div class="service-contact__author__image">
                                        <div class="service-contact__author__image__item">
                                            <img src="assets/images/service/man-1-1.png" alt="image">
                                        </div>
                                        <div class="service-contact__author__image__item">
                                            <img src="assets/images/service/man-1-2.png" alt="image">
                                        </div>
                                        <div class="service-contact__author__image__item">
                                            <img src="assets/images/service/man-1-3.png" alt="image">
                                        </div>
                                        <div class="service-contact__author__image__item">
                                            <img src="assets/images/service/man-1-4.png" alt="image">
                                        </div>
                                    </div>
                                    <span class="service-contact__author__name">500 Happy Clients</span>
                                </div>
                                <div class="service-contact__btn">
                                    <div class="service-contact__btn__icon">
                                        <i class="icon-telephone"></i>
                                    </div>
                                    <div class="service-contact__btn__content">
                                        <span class="service-contact__btn__title">have any question</span>
                                        <a href="tel:+2348140231032" class="service-contact__btn__link">+234-8140-231-032</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <form class="service-contact__form contact-form-validated form-one wow fadeInUp" data-wow-duration="1500ms" action="https://bracketweb.com/eolimn-html/inc/sendemail.php">
                                <div class="form-one__group">
                                    <div class="form-one__control form-one__control--full">
                                        <input type="text" name="name" placeholder="Full name">
                                    </div>
                                    <div class="form-one__control form-one__control--full">
                                        <input type="email" name="email" placeholder="email address">
                                    </div>
                                    <div class="form-one__control form-one__control--full">
                                        <input type="text" name="name" placeholder="phone number">
                                    </div>
                                    <div class="form-one__control form-one__control--full">
                                        <textarea name="message" placeholder="write messge. . ."></textarea>
                                    </div>
                                    <div class="form-one__control form-one__control--full">
                                        <button type="submit" class="eolimn-btn eolimn-btn--base">send message <i class="icon-arrow-point-to-right"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include("assets/include/footer.php"); ?>  
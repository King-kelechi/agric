
<?php include("assets/include/header.php"); ?>  
        <!-- main-slider-start -->
        <section class="main-slider-one">
            <div class="main-slider-one__carousel eolimn-owl__carousel owl-carousel" data-owl-options='{
		"loop": true,
		"animateOut": "fadeOut",
		"animateIn": "fadeIn",
		"items": 1,
		"autoplay": true,
		"autoplayTimeout": 7000,
		"smartSpeed": 1000,
		"nav": false,
		"dots": true,
		"margin": 0
	    }'>
                <div class="item">
                    <div class="main-slider-one__item">
                        <div class="main-slider-one__bg" style="background-image: url(assets/images/backgrounds/slider-1-1.jpg);"></div>
                        <span class="main-slider-one__line">mci-ng</span>
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="main-slider-one__content">
                                        <h5 class="main-slider-one__sub-title"> Climate Change Consulting
                                            <span class="main-slider-one__sub-title__line-group">
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--1"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--2"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--3"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--4"></span>
                                            </span>
                                        </h5>
                                        <h2 class="main-slider-one__title">renewable energy <br> solutions
                                            <img src="assets/images/backgrounds/hero-1-1.jpg" alt>
                                        </h2>
                                        <p class="main-slider-one__text">We drive the transition to more sustainable, reliable, and affordable energy systems. With our innovative technologies, we energize society, that’s our aim! The increase in extreme weather events. How can we meet the growing demand for electricity</p>
                                        <div class="main-slider-one__btn">
                                            <a href="services.php" class="eolimn-btn eolimn-btn--base">our services <i class="icon-arrow-point-to-right"></i></a>
                                            <a href="services.php" class="eolimn-btn">get a quote <i class="icon-arrow-point-to-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="main-slider-one__video" style="background-image: url(assets/images/backgrounds/play-video.png);">
                                        <a href="#" class="main-slider-one__video__popup video-popup"> play </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main-slider-one__shape">
                            <img src="assets/images/shapes/hero-shape-1-1.png" alt>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="main-slider-one__item">
                        <div class="main-slider-one__bg" style="background-image: url(assets/images/backgrounds/slider-1-2.jpg);"></div>
                        <span class="main-slider-one__line">mci-ng</span>
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="main-slider-one__content">
                                        <h5 class="main-slider-one__sub-title"> Efficient Waste Management
                                            <span class="main-slider-one__sub-title__line-group">
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--1"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--2"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--3"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--4"></span>
                                            </span>
                                        </h5>
                                        <h2 class="main-slider-one__title">Sustainable Land <br> Development
                                            <img src="assets/images/backgrounds/hero-1-1.jpg" alt>
                                        </h2>
                                        <p class="main-slider-one__text">Solar Products and Wind Turbines: We specialize in installing and distributing top-quality solar products and wind turbines, offering sustainable energy solutions for homes and businesses.</p>
                                        <div class="main-slider-one__btn">
                                            <a href="services.php" class="eolimn-btn eolimn-btn--base">our services <i class="icon-arrow-point-to-right"></i></a>
                                            <a href="contact.php" class="eolimn-btn">get a quote <i class="icon-arrow-point-to-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="main-slider-one__video" style="background-image: url(assets/images/backgrounds/play-video.png);">
                                        <a href="#" class="main-slider-one__video__popup video-popup"> play </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main-slider-one__shape">
                            <img src="assets/images/shapes/hero-shape-1-1.png" alt>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="main-slider-one__item">
                        <div class="main-slider-one__bg" style="background-image: url(assets/images/backgrounds/slider-1-3.jpg);"></div>
                        <span class="main-slider-one__line">mci-ng</span>
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="main-slider-one__content">
                                        <h5 class="main-slider-one__sub-title"> Advanced Energy-Saving Technologies
                                            <span class="main-slider-one__sub-title__line-group">
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--1"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--2"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--3"></span>
                                                <span class="main-slider-one__sub-title__line main-slider-one__sub-title__line--4"></span>
                                            </span>
                                        </h5>
                                        <h2 class="main-slider-one__title">Energy Optimization <br> Services
                                            <img src="assets/images/backgrounds/hero-1-1.jpg" alt>
                                        </h2>
                                        <p class="main-slider-one__text">Implementing cutting-edge energy-saving technologies, we help businesses optimize energy consumption and minimize waste.</p>
                                        <div class="main-slider-one__btn">
                                            <a href="services.php" class="eolimn-btn eolimn-btn--base">our services <i class="icon-arrow-point-to-right"></i></a>
                                            <a href="contact.php" class="eolimn-btn">get a quote <i class="icon-arrow-point-to-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="main-slider-one__video" style="background-image: url(assets/images/backgrounds/play-video.png);">
                                        <a href="#" class="main-slider-one__video__popup video-popup"> play </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main-slider-one__shape">
                            <img src="assets/images/shapes/hero-shape-1-1.png" alt>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- main-slider-end -->

        <!-- About Section Start -->
        <section class="about-one">
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-lg-6">
                        <div class="about-one__left">
                            <div class="about-one__thumb wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <img src="assets/images/gallery/gala5.jpg" alt="mci-ng image">
                                <div class="about-one__funfact count-box">
                                    <h3 class="about-one__count">
                                        <span class="count-text" data-stop="5" data-speed="1500"></span>
                                        <sub>+</sub>
                                    </h3>
                                    <p class="about-one__funfact__text">years of experience</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-one__content">
                            <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="sec-title__icon icon-solar-panel"></i>
                                    <h6 class="sec-title__tagline">about us</h6>
                                </div>
                                <h3 class="sec-title__title">We are the Best In solar energy Solutions</h3>
                            </div>
                            <p class="about-one__top__text about-one__top__text--text">Leading the Charge in Renewable Energy and Sustainable Solutions</p>
                            <p class="about-one__top__text">At Magnificent Catalytic Inclusions Limited, sustainability is at the core of everything we do. We are dedicated to providing innovative solutions that promote environmental stewardship and create a greener future.</p>
                            <ul class="about-one__list list-unstyled">
                                <li class="about-one__list__item"><i class="icon-checked"></i>Business Strategy Development</li>
                                <li class="about-one__list__item"><i class="icon-checked"></i>Renewable Energy Project Development and Solutions</li>
                                <li class="about-one__list__item"><i class="icon-checked"></i>Climate Change Consultancy  </li>
                                <li class="about-one__list__item"><i class="icon-checked"></i>Energy Accounting Solutions  </li>
                            </ul>
                            <a href="about.php" class="eolimn-btn">more about us <i class="icon-arrow-point-to-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-one__shape">
                <img src="assets/images/shapes/about-1-1.png" alt>
            </div>
        </section>
        <!-- About Section End -->

        <section class="solar-bar wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
            <div class="container">
                <div class="solar-bar__inner">
                    <div class="solar-bar__inner__bg" style="background-image: url(assets/images/shapes/solar-item-bg-1-1.png);"></div>
                    <ul class="solar-bar__list list-unstyled">
                        <li class="solar-bar__list__item">
                            <div class="solar-bar__list__content">
                                <div class="solar-bar__list__icon">
                                    <i class="icon-street-light-1"></i>
                                </div>
                                <h4 class="solar-bar__list__title"><a href="service-d-solar-service.php">Solar Light</a></h4>
                                <p class="solar-bar__list__text">Lighting the traffic system with solar</p>
                            </div>
                        </li>
                        <li class="solar-bar__list__item">
                            <div class="solar-bar__list__content">
                                <div class="solar-bar__list__icon">
                                    <i class="icon-traffic"></i>
                                </div>
                                <h4 class="solar-bar__list__title"><a href="service-d-hydropower-plants.php">Solar Traffic Lights</a></h4>
                                <p class="solar-bar__list__text">Lighting the traffic system with solar</p>
                            </div>
                        </li>
                        <li class="solar-bar__list__item">
                            <div class="solar-bar__list__content">
                                <div class="solar-bar__list__icon">
                                    <i class="icon-solar-panel-1"></i>
                                </div>
                                <h4 class="solar-bar__list__title"><a href="service-d-hydropower-plants.php"> Energy-Saving Technologies</a></h4>
                                <p class="solar-bar__list__text">Technologies and services aimed at optimizing energy </p>
                            </div>
                        </li>
                        <li class="solar-bar__list__item">
                            <div class="solar-bar__list__content">
                                <div class="solar-bar__list__icon">
                                    <i class="icon-battery-charge"></i>
                                </div>
                                <h4 class="solar-bar__list__title"><a href="service-d-wind-generator.php">Sustainable Infrastructure</a></h4>
                                <p class="solar-bar__list__text">eco-friendly environments that promote energy efficiency</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- Service Section Start -->
        <section class="service-one">
            <div class="service-one__bg jarallax" data-jarallax data-speed="0.3" data-imgPosition="50% -100%" style="background-image: url(assets/images/backgrounds/service-bg-1-1.png);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="d-flex align-items-center justify-content-start">
                                <i class="sec-title__icon icon-solar-panel"></i>
                                <h6 class="sec-title__tagline">our services</h6>
                            </div>
                            <h3 class="sec-title__title">what we offer</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="service-one__inner wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                    <div class="service-one__carousel eolimn-owl__carousel eolimn-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
				"items": 4,
				"margin": 30,
				"loop": true,
				"smartSpeed": 700,
				"nav": true,
				"navText": ["<span class=\"icon-arrow-point-to-left\"></span>","<span class=\"icon-arrow-point-to-right\"></span>"],
				"dots": false,
				"autoplay": true,
				"responsive": {
					"0": {
						"margin": 10,
						"items": 1
					},
					"600": {
						"margin": 10,
						"items": 2
					},
					"767": {
						"margin": 30,
						"items": 2
					},
					"992": {
						"margin": 30,
						"items": 3
					},
					"1300": {
						"margin": 30,
						"items": 3
					},
					"1600": {
						"margin": 30,
						"items": 4
					}
				}
				}'>
                        <div class="item">
                            <div class="service-one__item">
                                <div class="service-one__thumb">
                                    <img src="assets/images/service/service-2-1.jpg" alt="image">
                                </div>
                                <div class="service-one__content">
                                    <h4 class="service-one__content__title"><a href="service-d-energy-panels.php">Solar Panels Services</a></h4>
                                    <p class="service-one__content__text">we provide top-tier solar panel services designed to meet the energy needs of both residential and commercial clients. </p>
                                </div>
                                <div class="service-one__btn">
                                    <a href="service-d-energy-panels.php" class="service-one__btn__link"><span>service details</span> <i class="icon-arrow-point-to-right"></i></a>
                                    <a href="service-d-energy-panels.php" class="service-one__btn__link service-one__btn__link--hover"><i class="icon-arrow-point-to-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-one__item">
                                <div class="service-one__thumb">
                                    <img src="assets/images/service/service-2-2.jpg" alt="image">
                                </div>
                                <div class="service-one__content">
                                    <h4 class="service-one__content__title"><a href="service-d-solar-service.php">Turbines Services</a></h4>
                                    <p class="service-one__content__text">To develop technologies to capture monitor and mitigate and store CO2 emissions.</p>
                                </div>
                                <div class="service-one__btn">
                                    <a href="service-d-solar-service.php" class="service-one__btn__link"><span>service details</span> <i class="icon-arrow-point-to-right"></i></a>
                                    <a href="service-d-solar-service.php" class="service-one__btn__link service-one__btn__link--hover"><i class="icon-arrow-point-to-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-one__item">
                                <div class="service-one__thumb">
                                    <img src="assets/images/service/service-2-3.jpg" alt="image">
                                </div>
                                <div class="service-one__content">
                                    <h4 class="service-one__content__title"><a href="service-d-hydropower-plants.php">Hydropower Plants</a></h4>
                                    <p class="service-one__content__text">energy-saving technologies and services to optimize energy consumption and reduce waste.</p>
                                </div>
                                <div class="service-one__btn">
                                    <a href="service-d-hydropower-plants.php" class="service-one__btn__link"><span>service details</span> <i class="icon-arrow-point-to-right"></i></a>
                                    <a href="service-d-hydropower-plants.php" class="service-one__btn__link service-one__btn__link--hover"><i class="icon-arrow-point-to-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-one__item">
                                <div class="service-one__thumb">
                                    <img src="assets/images/service/service-2-4.jpg" alt="image">
                                </div>
                                <div class="service-one__content">
                                    <h4 class="service-one__content__title"><a href="service-d-thermo-stone.php">Solar products</a></h4>
                                    <p class="service-one__content__text">To install and distribute solar products, wind turbines, and other renewable energy systems and their outputs.</p>
                                </div>
                                <div class="service-one__btn">
                                    <a href="service-d-thermo-stone.php" class="service-one__btn__link"><span>service details</span> <i class="icon-arrow-point-to-right"></i></a>
                                    <a href="service-d-thermo-stone.php" class="service-one__btn__link service-one__btn__link--hover"><i class="icon-arrow-point-to-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="service-one__form__inner wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                <div class="container">
                    <div class="cta__form">
                        <div class="cta__form__left">
                            <div class="cta__form__title">
                                <div class="cta__form__title__inner">
                                    <i class="cta__form__title__icon icon-solar-panel"></i>
                                    <h6 class="cta__form__title__tagline">get our consultancy</h6>
                                </div>
                                <h3 class="sec-title__title">Call us for Consultancy</h3>
                            </div>
                            <a href="tel:+2348140231032" class="cta__form__btn"><span>+23481-4023-1032</span></a>
                        </div>
                        <div class="cta__form__right">
                            <form class="contact-one__form contact-form-validated form-one wow fadeInUp" data-wow-duration="1500ms" action="#">
                                <div class="form-one__group">
                                    <div class="form-one__control">
                                        <input type="text" name="name" placeholder="Full name">
                                    </div>
                                    <div class="form-one__control">
                                        <input type="email" name="email" placeholder="email">
                                    </div>
                                    <div class="form-one__control form-one__control--full">
                                        <button type="submit" class="eolimn-btn">send message <i class="icon-arrow-point-to-right"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="service-one__shape">
                <img src="assets/images/shapes/terbile.png" alt>
            </div>
        </section>
        <!-- Service Section End -->

        <!-- work process Section Start -->
        <section class="work-process-one">
            <div class="work-process-one__bg" style="background-image: url(assets/images/shapes/work-process-shape-1-1.png);"></div>
            <div class="container">
                <div class="sec-title text-center wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="sec-title__icon icon-solar-panel"></i>
                        <h6 class="sec-title__tagline">work process</h6>
                    </div>
                    <h3 class="sec-title__title">our work process</h3>
                </div>
                <div class="row gutter-y-30">
                    <div class="col-lg-4 col-md-6">
                        <div class="work-process-one__item  wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="work-process-one__item__top">
                                <div class="work-process-one__icon">
                                    <i class="icon-solar-house"></i>
                                </div>
                                <div class="work-process-one__item__number"></div>
                            </div>
                            <h4 class="work-process-one__title">getting started</h4>
                            <p class="work-process-one__text">Contact Magnificent Catalytic Inclusions Limited for a personalized quote and start your journey toward a sustainable energy future.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="work-process-one__item  wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                            <div class="work-process-one__item__top">
                                <div class="work-process-one__icon">
                                    <i class="icon-system"></i>
                                </div>
                                <div class="work-process-one__item__number"></div>
                            </div>
                            <h4 class="work-process-one__title">solar installation</h4>
                            <p class="work-process-one__text">We begin with a thorough consultation and site assessment to understand your energy needs and determine the best solar solution for your property.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="work-process-one__item  wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='700ms'>
                            <div class="work-process-one__item__top">
                                <div class="work-process-one__icon">
                                    <i class="icon-solar-system"></i>
                                </div>
                                <div class="work-process-one__item__number"></div>
                            </div>
                            <h4 class="work-process-one__title">ready to use</h4>
                            <p class="work-process-one__text">Regular maintenance is crucial for optimal solar panel performance. to keep your system running smoothly and efficiently</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- work process Section End -->

        <!-- FAQS Section Start -->
        <section class="faqs-two">
            <div class="faqs-two__bg" style="background-image: url(assets/images/shapes/faqs-shape-1-1.png);"></div>
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-lg-6">
                        <div class="faqs-two__thumb faqs-two__thumb--two wow fadeInLeft" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="faqs-two__thumb__item">
                                <img src="assets/images/gallery/gala8.jpg" alt="eolimn image">
                            </div>
                            <div class="faqs-two__thumb__item">
                                <div class="faqs-two__thumb__item__video">
                                    <div class="faqs-two__thumb__item__icon">
                                        <a href="#" class="faqs-two__video video-popup">
                                            <i class="icon-play"></i>
                                        </a>
                                    </div>
                                    <p class="faqs-two__thumb__item__text">Magnificent Catalytic Inclusions</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="d-flex align-items-center justify-content-start">
                                <i class="sec-title__icon icon-solar-panel"></i>
                                <h6 class="sec-title__tagline">QUESTIONS FOR US</h6>
                            </div>
                            <h3 class="sec-title__title">Some Faq Question?</h3>
                        </div>
                        <p class="faqs-two__top__text wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>At Magnificent Catalytic Inclusions Limited, we are dedicated to revolutionizing how the world approaches renewable energy, sustainable infrastructure, and climate change solutions. Our comprehensive services and innovative technologies are designed to address the pressing environmental challenges of today and pave the way for a greener, more sustainable future.</p>
                        <div class="faq-page__accordion-two eolimn-accrodion wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms' data-grp-name="eolimn-accrodion">
                            <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4 class="accrodion-title__text"><span class="accrodion-title__icon"></span>How do solar panels work?</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                        <p class="inner__text">The photovoltaic effect is the fundamental principle behind solar energy, This process converts light energy into electrical energy.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accrodion active">
                                <div class="accrodion-title">
                                    <h4 class="accrodion-title__text"><span class="accrodion-title__icon"></span>What are the main types of solar energy systems?</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                        <p class="inner__text">Discover the different types of solar energy systems, including grid-tied, off-grid, and hybrid systems. Get our consultant for better understanding</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4 class="accrodion-title__text"> <span class="accrodion-title__icon"></span>What are our plans on climate change?</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                        <p class="inner__text">To implement climate-smart agricultural practices, sustainable land and develop climate-resilient crops.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accrodion">
                                <div class="accrodion-title">
                                    <h4 class="accrodion-title__text"><span class="accrodion-title__icon"></span>How much space do I need for solar panels?</h4>
                                </div>
                                <div class="accrodion-content">
                                    <div class="inner">
                                        <p class="inner__text">On average, you need about 100 square feet of space for every 1 kW of solar panels.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="faqs-two__element">
                <img src="assets/images/shapes/faqs-1-1.png" alt>
            </div>
        </section>
        <!-- FAQS Section End -->

        <!-- Project Section Start -->
        <section class="project-one project-one--home">
            <div class="project-one__bg jarallax" data-jarallax data-speed="0.3" data-imgPosition="50% -100%" style="background-image: url(assets/images/backgrounds/project-bg-1-1.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <div class="d-flex align-items-center justify-content-start">
                                <i class="sec-title__icon icon-solar-panel"></i>
                                <h6 class="sec-title__tagline">LATEST PROJECT</h6>
                            </div>
                            <h3 class="sec-title__title">Our Latest Project</h3>
                        </div>
                    </div>
                </div>
                <div class="project-one__inner  wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                    <div class="project-one__carousel eolimn-owl__carousel  eolimn-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
				"items": 2,
				"margin": 0,
				"loop": true,
				"smartSpeed": 700,
				"nav": true,
				"navText": ["<span class=\"icon-arrow-point-to-left\"></span>","<span class=\"icon-arrow-point-to-right\"></span>"],
				"dots": false,
				"autoplay": false,
				"responsive": {
					"0": {
						"items": 1,
						"margin": 30
					},
					"576": {
						"items": 1,
						"margin": 30
					},
					"992": {
						"items": 2,
						"margin": 30
					}
				}
			}'>

                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/service/service-3-1.jpg" alt="mci-ng">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/service/service-3-2.jpg" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/gallery/gala1.jpg" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/gallery/gala3.jpg" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/gallery/gala4.avif" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/gallery/gala5.jpg" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/service/service-3-3.jpg" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="project-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="project-card__image">
                                    <img src="assets/images/service/service-3-4.jpg" alt="@@name">
                                </div>
                                <div class="project-card__hover">
                                    <div class="project-card__content">
                                        <span class="project-card__dec">solar energy</span>
                                        <h3 class="project-card__title"><a href="project-details.php">Solar Energy system</a></h3>

                                    </div>
                                    <a href="project-details.php" class="project-card__content__icon">
                                        <span class="project-card__content__icon__item"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Project Section End -->

        <!-- Gallery Section Start -->
        <div class="insagram-one">
            <div class="container">
                <div class="insagram-one__inner">
                    <ul class="insagram-one__list list-unstyled">
                        <li class="insagram-one__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms'>
                            <img src="assets/images/instagram/1.jpg" alt="eolimn">
                            <div class="insagram-one__item__icon">
                                <a href="https://www.instagram.com/"><span class="icon-instagram"></span></a>
                            </div>
                        </li>
                        <li class="insagram-one__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <img src="assets/images/instagram/2.jpg" alt="eolimn">
                            <div class="insagram-one__item__icon">
                                <a href="https://www.instagram.com/"><span class="icon-instagram"></span></a>
                            </div>
                        </li>
                        <li class="insagram-one__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                            <img src="assets/images/instagram/3.jpg" alt="eolimn">
                            <div class="insagram-one__item__icon">
                                <a href="https://www.instagram.com/"><span class="icon-instagram"></span></a>
                            </div>
                        </li>
                        <li class="insagram-one__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='700ms'>
                            <img src="assets/images/instagram/4.jpg" alt="eolimn">
                            <div class="insagram-one__item__icon">
                                <a href="https://www.instagram.com/"><span class="icon-instagram"></span></a>
                            </div>
                        </li>
                        <li class="insagram-one__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='900ms'>
                            <img src="assets/images/instagram/5.jpg" alt="eolimn">
                            <div class="insagram-one__item__icon">
                                <a href="https://www.instagram.com/"><span class="icon-instagram"></span></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Gallery Section End -->

        <div class="client-carousel ">
            <div class="container">
                <div class="client-carousel__one eolimn-owl__carousel owl-theme owl-carousel" data-owl-options='{
            "items": 5,
            "margin": 65,
            "smartSpeed": 700,
            "loop":true,
            "autoplay": 6000,
            "nav":false,
            "dots":false,
            "navText": ["<span class=\"icon-arrow-point-to-left\"></span>","<span class=\"icon-arrow-point-to-right\"></span>"],
            "responsive":{
                "0":{
                    "items":1,
                    "margin": 0
                },
                "360":{
                    "items":2,
                    "margin": 30
                },
                "575":{
                    "items":3,
                    "margin": 30
                },
                "768":{
                    "items":3,
                    "margin": 40
                },
                "992":{
                    "items": 4,
                    "margin": 40
                },
                "1200":{
                    "items": 5,
                    "margin": 140
                }
            }
            }'>
                    <div class="client-carousel__one__item">
                        <img class="client-carousel__one__image" src="assets/images/brand/brand-1-1.png" alt="eolimn">
                        <img class="client-carousel__one__hover-image" src="assets/images/brand/brand-hover-1-1.png" alt="eolimn">
                    </div>
                    <div class="client-carousel__one__item">
                        <img class="client-carousel__one__image" src="assets/images/brand/brand-1-2.png" alt="eolimn">
                        <img class="client-carousel__one__hover-image" src="assets/images/brand/brand-hover-1-2.png" alt="eolimn">
                    </div>
                    <div class="client-carousel__one__item">
                        <img class="client-carousel__one__image" src="assets/images/brand/brand-1-3.png" alt="eolimn">
                        <img class="client-carousel__one__hover-image" src="assets/images/brand/brand-hover-1-3.png" alt="eolimn">
                    </div>
                    <div class="client-carousel__one__item">
                        <img class="client-carousel__one__image" src="assets/images/brand/brand-1-4.png" alt="eolimn">
                        <img class="client-carousel__one__hover-image" src="assets/images/brand/brand-hover-1-4.png" alt="eolimn">
                    </div>
                    <div class="client-carousel__one__item">
                        <img class="client-carousel__one__image" src="assets/images/brand/brand-1-5.png" alt="eolimn">
                        <img class="client-carousel__one__hover-image" src="assets/images/brand/brand-hover-1-5.png" alt="eolimn">
                    </div>

                </div>
            </div>
        </div>

        <!-- Testimonials Section Start -->
        <section class="testimonial-one">
            <div class="testimonial-one__bg jarallax" data-jarallax data-speed="0.3" data-imgPosition="50% -100%" style="background-image: url(assets/images/gallery/gala1.jpg);"></div>
            <div class="container">
                <div class="row">
                    <div class="sec-title text-center sec-title--two wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                        <div class="d-flex align-items-center justify-content-center">
                            <i class="sec-title__icon icon-solar-panel"></i>
                            <h6 class="sec-title__tagline">our testimonial</h6>
                        </div>
                        <h3 class="sec-title__title">people’s talk about us</h3>
                    </div>
                    <div class="testimonial-one__inner wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                        <div class="testimonial-one__carousel eolimn-owl__carousel eolimn-owl__carousel--basic-nav owl-carousel owl-theme" data-owl-options='{
					"items": 1,
					"margin": 0,
					"loop": true,
					"smartSpeed": 700,
					"nav": false,
					"navText": ["<span class=\"icon-arrow-point-to-left\"></span>","<span class=\"icon-arrow-point-to-right\"></span>"],
					"dots": false,
					"autoplay": false,
					"responsive": {
						"0": {
							"items": 1
						},
						"576": {
							"items": 1,
							"margin": 30
						},
						"992": {
							"items": 2,
							"margin": 30
						}
					}
				}'>

                            
                            <div class="item">
                                <div class="testimonial-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
                                    <div class="testimonial-card__inner">
                                        <div class="testimonial-card__content">
                                            <h4 class="testimonial-card__title">solar energy service</h4>
                                            <p class="testimonial-card__text">I can't express how thrilled I am with my decision to switch to solar energy! After contemplating the idea for years, I finally took the plunge, and it's been a game-changer for both my wallet.</p>
                                        </div>
                                        <div class="testimonial-card__bottom">
                                            <div class="testimonial-card__author">
                                                <div class="testimonial-card__author__thumb">
                                                    <img src="assets/images/resources/testimonials-1-2.png" alt="mci-ng image">
                                                </div>
                                                <div class="testimonial-card__author__content">
                                                    <h5 class="testimonial-card__author__title">Sarah J. </h5>
                                                    <span class="testimonial-card__author__deg">Homeowner</span>
                                                </div>
                                            </div>
                                            <div class="testimonial-card__star">
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        </div>
                                        <div class="testimonial-card__quite">
                                            <i class="icon-double-quotes"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
                                    <div class="testimonial-card__inner">
                                        <div class="testimonial-card__content">
                                            <h4 class="testimonial-card__title">solar energy service</h4>
                                            <p class="testimonial-card__text">Their expertise in sustainable infrastructure is unparalleled. The energy-saving technologies they implemented have optimized our energy consumption and reduced our operational costs. </p>
                                        </div>
                                        <div class="testimonial-card__bottom">
                                            <div class="testimonial-card__author">
                                                <div class="testimonial-card__author__thumb">
                                                    <img src="assets/images/resources/testimonials.png" alt="mci-ng image">
                                                </div>
                                                <div class="testimonial-card__author__content">
                                                    <h5 class="testimonial-card__author__title">Michael T. </h5>
                                                    <span class="testimonial-card__author__deg">CEO of GreenTech Innovations</span>
                                                </div>
                                            </div>
                                            <div class="testimonial-card__star">
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        </div>
                                        <div class="testimonial-card__quite">
                                            <i class="icon-double-quotes"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
                                    <div class="testimonial-card__inner">
                                        <div class="testimonial-card__content">
                                            <h4 class="testimonial-card__title">solar energy service</h4>
                                            <p class="testimonial-card__text">Their climate-smart agriculture solutions have helped us develop climate-resilient crops and manage our land more sustainably. </p>
                                        </div>
                                        <div class="testimonial-card__bottom">
                                            <div class="testimonial-card__author">
                                                <div class="testimonial-card__author__thumb">
                                                    <img src="assets/images/resources/testimonials-1-2.png" alt="eolimn image">
                                                </div>
                                                <div class="testimonial-card__author__content">
                                                    <h5 class="testimonial-card__author__title">Laura M.</h5>
                                                    <span class="testimonial-card__author__deg">Organic Farmer</span>
                                                </div>
                                            </div>
                                            <div class="testimonial-card__star">
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            
                                            </div>
                                        </div>
                                        <div class="testimonial-card__quite">
                                            <i class="icon-double-quotes"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
                                    <div class="testimonial-card__inner">
                                        <div class="testimonial-card__content">
                                            <h4 class="testimonial-card__title">solar energy service</h4>
                                            <p class="testimonial-card__text">Their consulting services have provided us with actionable strategies to reduce CO2 emissions and adapt to climate change. Their commitment to sustainability and deep knowledge in the field are commendable.</p>
                                        </div>
                                        <div class="testimonial-card__bottom">
                                            <div class="testimonial-card__author">
                                                <div class="testimonial-card__author__thumb">
                                                    <img src="assets/images/resources/testimonials.png" alt="eolimn image">
                                                </div>
                                                <div class="testimonial-card__author__content">
                                                    <h5 class="testimonial-card__author__title"> David B.</h5>
                                                    <span class="testimonial-card__author__deg">Environmental Policy</span>
                                                </div>
                                            </div>
                                            <div class="testimonial-card__star">
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                            </div>
                                        </div>
                                        <div class="testimonial-card__quite">
                                            <i class="icon-double-quotes"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonials Section End -->

       

        <!-- Blog Section Start -->
        <section class="blog-two">
            <div class="container">
                <div class="sec-title text-center wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="sec-title__icon icon-solar-panel"></i>
                        <h6 class="sec-title__tagline">letest blog</h6>
                    </div>
                    <h3 class="sec-title__title">Our Latest Blog</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-two__left">
                            <div class="blog-two__card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <div class="blog-two__card__image">
                                    <a href="blog-details-right.php" class="blog-two__card__image__item">
                                        <img src="assets/images/gallery/gala5.jpg" alt="mci-ng image">
                                    </a>
                                    <div class="blog-two__card__date"><span class="blog-two__card__date__day">28</span> <span class="blog-two__card__date__month">June</span></div>
                                </div>
                                <div class="blog-two__card__content">
                                    <ul class="blog-two__card__meta list-unstyled">
                                        <li class="blog-two__card__meta__item"><a href="blog-details.php"><i class="icon-user"></i>by Admin</a></li>
                                        <li class="blog-two__card__meta__item"><a href="blog-details.php"><i class="icon-comments-icon"></i>2 Comments</a></li>
                                    </ul>
                                    <h3 class="blog-two__card__title"><a href="blog-details-right.php">Collaboratively pontificate bleeding edge resources with inexpensive methodologies</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="blog-two__right">
                            <div class="blog-two__list">
                                <div class="blog-two__list__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                                    <a href="blog-details-right.php" class="blog-two__list__image">
                                        <img src="assets/images/blog/blog-s-2-1.jpg" alt="eolimn image">
                                    </a>
                                    <div class="blog-two__list__content">
                                        <ul class="blog-two__list__meta list-unstyled">
                                            <li class="blog-two__list__meta__item"><a href="blog-details.php"><i class="icon-user"></i>by Admin</a></li>
                                            <li class="blog-two__list__meta__item"><a href="blog-details.php"><i class="icon-comments-icon"></i>8 Comments</a></li>
                                        </ul>
                                        <h4 class="blog-two__list__title"><a href="blog-details-right.php">Get our amazing offers</a></h4>
                                        <div class="blog-two__list__date"><span class="blog-two__card__date__day">20</span> <span class="blog-two__card__date__month">June</span></div>
                                    </div>
                                </div>
                                <div class="blog-two__list__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='700ms'>
                                    <a href="blog-details-right.php" class="blog-two__list__image">
                                        <img src="assets/images/blog/blog-s-2-2.jpg" alt="eolimn image">
                                    </a>
                                    <div class="blog-two__list__content">
                                        <ul class="blog-two__list__meta list-unstyled">
                                            <li class="blog-two__list__meta__item"><a href="blog-details.php"><i class="icon-user"></i>by Admin</a></li>
                                            <li class="blog-two__list__meta__item"><a href="blog-details.php"><i class="icon-comments-icon"></i>2 Comments</a></li>
                                        </ul>
                                        <h4 class="blog-two__list__title"><a href="blog-details-right.php">Magnificent Catalytic Inclusions Limited: Leading the Charge in Sustainability and Renewable Energy</a></h4>
                                        <div class="blog-two__list__date"><span class="blog-two__card__date__day">25</span> <span class="blog-two__card__date__month">June</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="blog-two__element-one">
                <img src="assets/images/shapes/blog-1-1.png" alt>
            </div>
            <div class="blog-two__element-two">
                <img src="assets/images/shapes/blog-1-2.png" alt>
            </div>
        </section>
        <!-- Blog Section End -->

        <?php include("assets/include/footer.php"); ?>  
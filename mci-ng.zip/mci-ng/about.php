<?php include("assets/include/header.php"); ?>  
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(assets/images/backgrounds/page-header-bg-1-1.jpg);"></div>
            <!-- Sliding section Start -->
            <div class="text-slider  wow fadeInUp" data-wow-delay="500ms">
                <div class="text-slider__inner">
                    <div class="text-slider__item">
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                        <div class="text-slider__item__text"><span>*</span> Magnificent Catalytic Inclusions</div>
                    </div>
                </div>
            </div>
            <!-- Sliding section End -->
            <div class="container">
                <h2 class="page-header__title">About us</h2>
                <div class="eolimn-breadcrumb">
                    <ul class="eolimn-breadcrumb__list list-unstyled">
                        <li class="eolimn-breadcrumb__list__item"><a href="index.php">Home</a></li>
                        <li class="eolimn-breadcrumb__list__item"><span>About us</span></li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- About Section Start -->
        <section class="about-two">
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-lg-6">
                        <div class="about-two__left">
                            <div class="about-two__thumb">
                                <div class="about-two__thumb__item wow fadeInLeft" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <img src="assets/images/about/about-2-1.png" alt="mci-ng image">
                                </div>
                                <div class="about-two__thumb__item about-two__thumb__item--two wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <img src="assets/images/gallery/gala7.jpg" alt="mci-ng image">
                                    <div class="about-two__experience">
                                        <a href="#" class="about-two__video video-popup">
                                            <i class="icon-play"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="about-two__box wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <div class="about-two__box__icon">
                                        <i class="icon-bage"></i>
                                    </div>
                                    <h2 class="about-two__box__title">5 Years</h2>
                                    <p class="about-two__box__text">Working Experience</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-two__content">
                            <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="sec-title__icon icon-solar-panel"></i>
                                    <h6 class="sec-title__tagline">about us</h6>
                                </div>
                                <h3 class="sec-title__title">We are the Best In solar energy Solutions</h3>
                            </div>
                            <p class="about-two__content__top__text wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>At Magnificent Catalytic Inclusions Limited, we are dedicated to revolutionizing how the world approaches renewable energy, sustainable infrastructure, and climate change solutions. Our comprehensive services and innovative technologies are designed to address the pressing environmental challenges of today and pave the way for a greener, more sustainable future.</p>

                            <ul class="about-two__content__feature list-unstyled">
                                <li class="about-two__content__feature__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <div class="about-two__content__feature__icon">
                                        <i class="icon-solar-panels"></i>
                                    </div>
                                    <div class="about-two__content__feature__content">
                                        <h4 class="about-two__content__feature__title">Innovative Renewable Energy Solutions</h4>
                                        <p class="about-two__content__feature__text">We specialize in the installation and distribution of cutting-edge renewable energy systems, including solar products, wind turbines, and other sustainable energy outputs.</p>
                                    </div>
                                </li>
                                <li class="about-two__content__feature__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                    <div class="about-two__content__feature__icon">
                                        <i class="icon-solar-house"></i>
                                    </div>
                                    <div class="about-two__content__feature__content">
                                        <h4 class="about-two__content__feature__title">Sustainable Infrastructure Development</h4>
                                        <p class="about-two__content__feature__text">Our expertise extends to the development of sustainable infrastructure projects, such as green buildings, green roofs, and sustainable transportation systems.</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Section End -->

        <!-- Why Choose Section Start -->
        <section class="why-choose-two">
            <div class="why-choose-two__bg" style="background-image: url(assets/images/shapes/why-choose-1-1.png);"></div>
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-lg-8">
                        <div class="why-choose-two__content">
                            <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="sec-title__icon icon-solar-panel"></i>
                                    <h6 class="sec-title__tagline">why choose us</h6>
                                </div>
                                <h3 class="sec-title__title">Most used bio energy <br> in the world</h3>
                            </div>
                            <div class="row gutter-y-30 gutter-x-30">
                                <div class="col-md-6">
                                    <div class="why-choose-two__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                        <h4 class="why-choose-two__title">Advanced Energy-Saving Technologies</h4>
                                        <p class="why-choose-two__text">We implement state-of-the-art energy-saving technologies and services to optimize energy consumption and minimize waste. </p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="why-choose-two__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                                        <h4 class="why-choose-two__title">CO2 Emission Mitigation Technologies</h4>
                                        <p class="why-choose-two__text">for capturing, monitoring, mitigating, and storing CO2 emissions are at the forefront of the fight against climate change.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="why-choose-two__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                        <h4 class="why-choose-two__title">Climate-Smart Agriculture Practices</h4>
                                        <p class="why-choose-two__text">Our innovative approaches ensure food security and environmental sustainability in the face of changing climate conditions.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="why-choose-two__item wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms'>
                                        <h4 class="why-choose-two__title">Expert Climate Change Consulting</h4>
                                        <p class="why-choose-two__text">We provide expert consulting services to businesses and governments on climate change mitigation and adaptation strategies. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="why-choose-two__thumb wow fadeInRight" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <img src="assets/images/resources/why-choose-1-1.jpg" alt="image">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Why Choose Section End -->

       

        <!-- FQAS Section Start -->
        <section class="faqs-one">
            <div class="faqs-one__bg" style="background-image: url(assets/images/shapes/faqs-shape-1-1.png);"></div>
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-lg-6">
                        <div class="faqs-one__thumb wow fadeInLeft" data-wow-duration='1500ms' data-wow-delay='300ms'>
                            <img src="assets/images/gallery/gala3.jpg" alt="image">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="faqs-one__content">
                            <div class="sec-title wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                                <div class="d-flex align-items-center justify-content-start">
                                    <i class="sec-title__icon icon-solar-panel"></i>
                                    <h6 class="sec-title__tagline">QUESTIONS FOR US</h6>
                                </div>
                                <h3 class="sec-title__title">Some Faq Question?</h3>
                            </div>
                            <p class="faqs-one__content__top__text wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>Explore Magnificent Catalytic Inclusions Limited, a leader in renewable energy systems, sustainable infrastructure, energy-saving technologies, CO2 emission mitigation, climate-smart agriculture, waste management, and climate change consulting.</p>

                            <div class="faq-page__accordion-two eolimn-accrodion wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='500ms' data-grp-name="eolimn-accrodion">
                                <div class="accrodion">
                                    <div class="accrodion-title">
                                        <h4 class="accrodion-title__text"><span class="accrodion-title__icon"></span>How do solar panels work?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p class="inner__text">The photovoltaic effect is the fundamental principle behind solar energy, This process converts light energy into electrical energy.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accrodion active">
                                    <div class="accrodion-title">
                                        <h4 class="accrodion-title__text"><span class="accrodion-title__icon"></span>What are the main types of solar energy systems?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p class="inner__text">Discover the different types of solar energy systems, including grid-tied, off-grid, and hybrid systems. Get our consultant for better understanding</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accrodion">
                                    <div class="accrodion-title">
                                        <h4 class="accrodion-title__text"> <span class="accrodion-title__icon"></span>What are our plans on climate change?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p class="inner__text">To implement climate-smart agricultural practices, sustainable land and develop climate-resilient crops.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accrodion">
                                    <div class="accrodion-title">
                                        <h4 class="accrodion-title__text"><span class="accrodion-title__icon"></span>How much space do I need for solar panels?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p class="inner__text">On average, you need about 100 square feet of space for every 1 kW of solar panels.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="faqs-two__element">
                <img src="assets/images/shapes/faqs-1-1.png" alt>
            </div>
        </section>
        <!-- FAQS Section End -->
        <?php include("assets/include/footer.php"); ?>  